# Chemie Quiz

Interaktive Chemie-Lernkarten fuer iPhone Safari und GitHub Pages.

## Inhalt

- `index.html` - komplette Quiz-App mit Kartenmodus, Swipe, Fehlerliste und Motivation
- `manifest.json` - Web-App-Metadaten fuer iPhone/Android
- `sw.js` - Offline-Cache fuer installierte Web-App
- `audio/bachata_5s.wav` - kurzer Bachata/Halleluja-Sound

## GitHub Pages

1. Neues GitHub-Repository erstellen.
2. Alle Dateien aus diesem Ordner in das Repository hochladen.
3. In GitHub zu `Settings` -> `Pages` gehen.
4. Bei `Build and deployment` entweder `Deploy from a branch` waehlen und `main` / `/root` auswaehlen, oder den vorhandenen Workflow unter `.github/workflows/pages.yml` verwenden.
5. Die Seite ist danach unter `https://DEIN-NAME.github.io/REPO-NAME/` erreichbar.

## iPhone

1. Die GitHub-Pages-Adresse in Safari oeffnen.
2. Unten auf Teilen tippen.
3. `Zum Home-Bildschirm` waehlen.
4. Danach startet das Quiz wie eine App.

## Hinweis

Die App ist statisch und braucht keinen Server, keine Datenbank und keine Installation. Ton und Sprachausgabe muessen auf iPhone Safari einmal durch Antippen gestartet werden.
